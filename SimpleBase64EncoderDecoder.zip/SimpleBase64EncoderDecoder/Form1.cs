﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics;
using System.Threading;

namespace SimpleBase64EncoderDecoder
{
    public partial class Form1 : Form   
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            if (!Directory.Exists("C:\\SimpleBase64EncoderDecoder"))
            {
                Directory.CreateDirectory("C:\\SimpleBase64EncoderDecoder");
            }
        }

        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

            string patch = textBox1.Text;
            StreamReader str = new StreamReader(patch);
            string Text = str.ReadToEnd();
            byte[] bytes = Encoding.UTF8.GetBytes(Text);
            string Encoded = Convert.ToBase64String(bytes);
            str.Close();
            if(checkBox1.Checked == true)
            {
            File.WriteAllText(patch, Encoded);
            }else if(checkBox1.Checked == false)
            {
              var mFile = File.Create("C:\\SimpleBase64EncoderDecoder\\Encoded.txt");mFile.Close();
                File.WriteAllText("C:\\SimpleBase64EncoderDecoder\\Encoded.txt", Encoded);
            }
            MessageBox.Show("Encoded: " + patch, "Encoder", MessageBoxButtons.OK);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string patch = textBox2.Text;
            StreamReader str = new StreamReader(@patch);
            byte[] data = Convert.FromBase64String(str.ReadToEnd());
            string decodedString = Encoding.UTF8.GetString(data);
            str.Close();
            if (checkBox2.Checked == true)
            {
             File.WriteAllText(patch, decodedString);
             MessageBox.Show("Decoded: " + patch, "Decoder", MessageBoxButtons.OK);
            }
            else if (checkBox2.Checked == false)
            {
                if (!Directory.Exists("C:\\SimpleBase64EncoderDecoder"))
                {
                    Directory.CreateDirectory("C:\\SimpleBase64EncoderDecoder");
                }
                var mFile = File.Create("C:\\SimpleBase64EncoderDecoder\\Decoded.txt");mFile.Close();
                File.WriteAllText("C:\\SimpleBase64EncoderDecoder\\Decoded.txt", decodedString);
                
                MessageBox.Show("Decoded: " + "C:\\SimpleBase64EncoderDecoder\\Decoded.txt", "Decoder", MessageBoxButtons.OK);
            }
        }

        private void label4_Click(object sender, EventArgs e)
        {
            string GH = "/C start https://github.com/0x01MTX";
            System.Diagnostics.Process.Start("cmd.exe", GH);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.InitialDirectory = "c:\\SimpleBase64EncoderDecoder";
            openFileDialog.ShowDialog();
        }
    }
}
